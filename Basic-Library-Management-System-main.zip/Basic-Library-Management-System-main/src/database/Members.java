package database;

public class Members {
	private int MemberID;
	private String Name;

	public int getMemberID() {
		return MemberID;
	}

	public void setMemberID(int memberID) {
		MemberID = memberID;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}
}